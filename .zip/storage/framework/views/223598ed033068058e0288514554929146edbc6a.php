<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<?php if(count($list) != 0): ?>
	<?php if(in_array('update_direction',session('InfosAction')) || in_array('delete_direction',session('InfosAction')) ): ?>
		<?php if(in_array('update_direction',session('InfosAction'))): ?>
			<button type='button' class='btn btn-success btn-label right waves-light rounded-pill' id='btn-modifier'><i class='ri-check-double-line label-icon align-middle fs-16 ms-2 rounded-pill'></i> Modifier</button>
		<?php endif; ?>
		<?php if(in_array('delete_direction',session('InfosAction'))): ?>
			<button type='button' class='btn btn-danger btn-label right waves-light rounded-pill' id='btn-supprimer'><i class='ri-delete-bin-6-line label-icon align-middle fs-16 ms-2 rounded-pill'></i> Supprimer</button>
		<?php endif; ?>
	<?php endif; ?>
	<table class="table table-striped table-bordered table-nowrap mt-4">
		<thead><tr>
			<th scope='col'></th>
			<th scope="col" ><?php echo trans('data.code_direc'); ?></th>
			<th scope="col" ><?php echo trans('data.lib_direc'); ?></th>
			<?php if(in_array('init_giwu',session('InfosAction'))): ?>
			<th scope="col" class="text-center"><?php echo trans('data.respo_id'); ?></th>
			<?php endif; ?>
			<?php if(in_array('init_giwu',session('InfosAction'))): ?>
			<th scope="col" class="text-center"><?php echo trans('data.init_id'); ?></th>
			<?php endif; ?>
		</tr></thead>
		<tbody>
			<?php $__currentLoopData = $list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $listgiwu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<tr>
					<td class='text-center'><input class='form-check-input checkradio' data-id='<?php echo e($listgiwu->id_direc); ?>'  type='radio' name='formradiocolor9' id='formradioRight13'></td>
					<td><?php echo $listgiwu->code_direc; ?></td>
					<td><?php echo $listgiwu->lib_direc; ?></td>
					<td><?php echo isset($listgiwu->responsable) ? $listgiwu->responsable->name." ".$listgiwu->responsable->prenom : trans('data.not_found'); ?></td>
					<?php if(in_array('init_giwu',session('InfosAction'))): ?>
						<td><?php echo isset($listgiwu->users_g) ? $listgiwu->users_g->name." ".$listgiwu->users_g->prenom : trans('data.not_found'); ?></td>
					<?php endif; ?>
				</tr>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		</tbody>
	</table>
	
	<?php echo $list->appends(['query'=>(isset($_GET['query'])?$_GET['query']:'') ])->links(); ?>

<?php else: ?>
	<div Class="alert alert-info"><strong>Info! </strong> <?php echo trans('data.AucunInfosTrouve'); ?> </div>
<?php endif; ?>
<?php /**PATH C:\Users\DELL\Documents\Mes Applications\csm_app\resources\views/direction/index-search.blade.php ENDPATH**/ ?>