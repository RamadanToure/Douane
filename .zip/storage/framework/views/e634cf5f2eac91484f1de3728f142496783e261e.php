<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<?php if(count($list) != 0): ?>
    <table class="table table-striped table-bordered table-nowrap">
        <thead>
            <tr>
                <th scope="col"><?php echo e(trans('data.matricule')); ?></th>
                <th scope="col"><?php echo e(trans('data.name')." ".trans('data.prenom')); ?></th>
                <th scope="col"><?php echo e(trans('data.email')); ?></th>
                <th scope="col"><?php echo e(trans('data.tel_user')); ?></th>
                <th scope="col"><?php echo e(trans('data.lib_role')); ?></th>
                <th scope="col"><?php echo e(trans('data.id_fonct')); ?></th>
                <th scope="col" class="text-center"><?php echo e(trans('data.is_active')); ?></th>
                <?php if(in_array('update_user',session('InfosAction')) || in_array('delete_user',session('InfosAction'))): ?>
                    <th class="text-center"> Actions</th>
                <?php endif; ?>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $listgiwu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($listgiwu->matricule); ?></td>
                    <td><?php echo e($listgiwu->name." ".$listgiwu->prenom); ?></td>
                    <td><?php echo e($listgiwu->email); ?></td>
                    <td><?php echo e($listgiwu->tel_user); ?></td>
                    <td><?php echo e(isset($listgiwu->role) ? $listgiwu->role->libelle_role : trans('data.not_found')); ?></td>
                    <td><?php echo e(trans('entite.type_destinataire')[$listgiwu->type_fonct].' : '.$listgiwu->fonction($listgiwu->type_fonct,$listgiwu->id_fonct)); ?></td>
                    <td class="text-center">
                        <?php if($listgiwu->is_active == 1): ?><span class="badge bg-success">Activé</span> <?php else: ?> <span class="badge bg-danger">Désactivé</span> <?php endif; ?>
                    </td>
                    <?php if(in_array('update_user',session('InfosAction')) || in_array('delete_user',session('InfosAction'))): ?>
                        <td class="text-center">
                            <?php if(in_array('update_user',session('InfosAction'))): ?>
                            <a href="<?php echo e(route('users.edit', $listgiwu->id)); ?>" title='Modifier' class="btn btn-success btn-sm  waves-effect waves-light"><i class="ri-edit-2-line"></i></a>

                            <?php endif; ?>
                            <?php if(in_array('delete_user',session('InfosAction'))): ?>
                                <button type="button"  title='Supprimer' data-id="<?php echo e($listgiwu->code); ?>" class="btn btn-danger btn-sm  waves-effect waves-light btn-delete" data-bs-toggle="modal" ><i class="ri-delete-bin-6-line"></i></button>
                            <?php endif; ?>
                        </td>
                    <?php endif; ?>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </tbody>
    </table>
    <?php echo $list->appends([
        'query'=>(isset($_GET['query'])?$_GET['query']:'')
        ])->links(); ?>

<?php else: ?>
	<div class="alert alert-info"><strong>Info! </strong> <?php echo trans('data.AucunInfosTrouve'); ?> </div>
<?php endif; ?>
<?php /**PATH C:\Users\DELL\Documents\Mes Applications\csm_app\resources\views/users/index-search.blade.php ENDPATH**/ ?>