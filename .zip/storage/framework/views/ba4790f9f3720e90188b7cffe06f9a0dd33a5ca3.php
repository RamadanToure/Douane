<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<?php if(count($list) != 0): ?>
	<table class="table table-striped table-bordered table-nowrap">
		<thead><tr>
			<?php if(in_array('update_courrier',session('InfosAction')) || in_array('delete_courrier',session('InfosAction')) || in_array('transfert_courrier',session('InfosAction')) ): ?>
				<th class="text-center"> Actions</th>
			<?php endif; ?>
			<th scope="col" ><?php echo trans('data.ref_cour'); ?></th>
			<th scope="col" ><?php echo trans('data.code_check'); ?></th>
			<th scope="col" class="text-center"><?php echo trans('data.piece_jointe_cour'); ?></th>
			<th scope="col" class="text-center"><?php echo trans('data.date_rece'); ?></th>
			<th scope="col" class="text-center"><?php echo trans('data.date_limite'); ?></th>
			<th scope="col" class="text-center"><?php echo trans('data.expe_id'); ?></th>
			<th scope="col" ><?php echo trans('data.sujet_cour'); ?></th>
			<th scope="col" ><?php echo trans('data.statut_cour'); ?></th>
			<th scope="col" ><?php echo trans('data.priorite_cour'); ?></th>
			<th scope="col" class="text-center"><?php echo trans('data.direc_id'); ?></th>
			<!-- <th scope="col" ><?php echo trans('data.commentaire_cour'); ?></th> -->
			<?php if(in_array('init_giwu',session('InfosAction'))): ?>
			<th scope="col" class="text-center"><?php echo trans('data.init_id'); ?></th>
			<?php endif; ?>
		</tr></thead>
		<tbody>
			<?php $__currentLoopData = $list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $listgiwu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<tr>
					<?php if(in_array('update_courrier',session('InfosAction')) || in_array('delete_courrier',session('InfosAction')) ): ?>
						<td class="text-center">
							<?php if(in_array('update_courrier',session('InfosAction'))): ?>
								<a href="<?php echo e(route('courrier.edit',$listgiwu->id_cour)); ?>" title='Modifier' class="btn btn-success btn-sm  waves-effect waves-light"><i class="ri-edit-2-line"></i></a>
							<?php endif; ?>
							<?php if(in_array('delete_courrier',session('InfosAction'))): ?>
								<button type="button"  title='Supprimer' data-id="<?php echo e($listgiwu->id_cour); ?>" class="btn btn-danger btn-sm  waves-effect waves-light btn-delete" data-bs-toggle="modal" ><i class="ri-delete-bin-6-line"></i></button>
							<?php endif; ?>
							<?php if(in_array('transfert_courrier',session('InfosAction'))): ?>
                                <button type="button" title='Envoyer le courrier au destinataire' data-id="<?php echo e($listgiwu->id_cour); ?>" class="btn btn-sm btn-warning waves-effect waves-light btn-transfert"  data-toggle="modal"><i class="ri-share-line"></i></button>
                            <?php endif; ?>
						</td>
					<?php endif; ?>
					<td><?php echo $listgiwu->ref_cour; ?></td>
					<td><?php echo $listgiwu->code_check; ?></td>
					<td class="text-center">
						<?php if($listgiwu->piece_jointe_cour): ?>
							<a href='<?php echo e("assets/courrier/".$listgiwu->piece_jointe_cour); ?>' title="<?php echo $listgiwu->piece_jointe_cour; ?>" target="_blank" class="badge bg-success">Ouvrir</a>
						<?php else: ?> <span class="badge bg-danger">Aucun</a>  <?php endif; ?>
					</td>
					<td class="text-center"><?php echo e(date('d/m/Y',strtotime($listgiwu->date_rece))); ?></td>
					<td class="text-center"><?php echo e(date('d/m/Y',strtotime($listgiwu->date_limite))); ?></td>
					<td><?php echo isset($listgiwu->expediteur) ? $listgiwu->expediteur->nom_expe : trans('data.not_found'); ?></td>
					<td><?php echo $listgiwu->sujet_cour; ?></td>
					<td><?php echo trans('entite.statut_courrier')[$listgiwu->statut_cour]; ?></td>
					<td><?php echo trans('entite.priorite_courrier')[$listgiwu->priorite_cour]; ?></td>
					<td title="<?php echo e(isset($listgiwu->direction) ? $listgiwu->direction->lib_direc : trans('data.not_found')); ?>"><?php echo isset($listgiwu->direction) ? $listgiwu->direction->code_direc : trans('data.not_found'); ?></td>
					<!-- <td><?php echo $listgiwu->commentaire_cour; ?></td> -->
					<?php if(in_array('init_giwu',session('InfosAction'))): ?>
						<td><?php echo isset($listgiwu->users_g) ? $listgiwu->users_g->name." ".$listgiwu->users_g->prenom : trans('data.not_found'); ?></td>
					<?php endif; ?>
				</tr>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		</tbody>
	</table>
	
	<?php echo $list->appends(['query'=>(isset($_GET['query'])?$_GET['query']:'') ])->links(); ?>

<?php else: ?>
	<div Class="alert alert-info"><strong>Info! </strong> <?php echo trans('data.AucunInfosTrouve'); ?> </div>
<?php endif; ?>
<?php /**PATH C:\Users\DELL\Documents\Mes Applications\csm_app\resources\views/courrier/index-search.blade.php ENDPATH**/ ?>